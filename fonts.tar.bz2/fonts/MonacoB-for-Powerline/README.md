The Monaco font, patched for Powerline / Airline.
-------------------------------------------------

Optimised for iTerm2 on OSX @ 10pt 

Patched with  [fontpatcher](https://github.com/powerline/fontpatcher)
Use the attached source font.

Enjoy /Flemming
